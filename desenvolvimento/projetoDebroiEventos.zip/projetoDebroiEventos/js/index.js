document.addEventListener('DOMContentLoaded', function () {
    console.log("Página inicial carregada!");
});
